//============================================================================
// Description : This Program Finds Magic Squares
//============================================================================

#include <iostream>
#include <iomanip>
#include <array>
#include <ctime>
#include <random>
#include <cstdlib>
#include <algorithm>
using namespace std;

//As a beginner in C++, I learnt a lot through doing this little challenge that I found online, which is to
//make a magic square that would be able to determine if a combination of 9 numbers is a magic sqare. Note that
//a magic square occurs when the sum of all rows, columns and diagonals of a 3 x 3 square is equivalent to 15.

//PLEASE RUN THIS PROGRAM IN ECLIPSE AS A C++ FILE

int randomNum (int i) {return std::rand()%i;}

/*********************************** Defining the functions Intro ******************************************/
	array< array<int, 3>, 3> fillBoard ();
	bool isMagic (array< array<int, 3>, 3>);
	int showBoard (array< array<int, 3>, 3>);

/*************************************** Excuting the functions ******************************************/
	int main()
	{
		srand (time(NULL));

		// Introduction of the program
			cout << endl;
			cout << "This program finds Magic Squares" << endl;
			cout << "****************************************************************************************" << endl;

		//Prompting the user to enter the iteration number
		int iterationNum;
		cout<<"Please enter the number of iterations you wish to compute: ";
		cin>> iterationNum;

		int num = 0;
		//Determing the magic squares and di
		for (int i =0; i<=iterationNum; i++)
		{
			array <array<int, 3>, 3>board;
			board = fillBoard ();


			if(isMagic (board))
			{
			showBoard (board);
			++num;
			}
		}

		cout << "Number of Magic Squares : " << num << endl;

		return 0;
	}

/********************************************* Functions Themselves ***************************************/

///////FILLBOARD FUNCTION:

	array< array<int, 3>, 3> fillBoard ()
		{
			array< array<int, 3>, 3> square;
			array<int,9> randomArray = {1,2,3,4,5,6,7,8,9};

			random_shuffle(randomArray.begin(), randomArray.end(),randomNum);

			int arrayBox =0;

			for(int j = 0; j<3; j++)
			{
				for(int k =0; k<3; k++ )
				{
					square[j][k] = randomArray[arrayBox];
					++arrayBox;
				}
			}
		return square;
		}

///////ISMAGIC FUNCTION

	bool isMagic(array< array<int, 3>, 3> square)
	{
		bool checkMagic = 1;

		//For the rows:

			if (square[0][0] + square[0][1] + square[0][2] !=15)
			{
				//cout <<"This is not a magic square"<<endl;
				checkMagic = 0;
			}
			else if (square[1][0] + square[1][1] + square[1][2] !=15)
			{
				//cout <<"This is not a magic square"<<endl;
				checkMagic = 0;
			}
			else if (square[2][0] + square[2][1] + square[2][2] !=15)
			{
				//cout <<"This is not a magic square"<<endl;
				checkMagic = 0;
			}

		//For the columns:
			else if (square[0][0] + square[1][0] + square[2][0] !=15)
			{
				//cout <<"This is not a magic square"<<endl;
				checkMagic = 0;
			}
			else if (square[0][1] + square[1][1] + square[2][1] !=15)
			{
				//cout <<"This is not a magic square"<<endl;
				checkMagic = 0;
			}
			else if (square[0][2] + square[1][2] + square[2][2] !=15)
			{
				//cout <<"This is not a magic square"<<endl;
				checkMagic = 0;
			}

		//For the diagonal 1:
			else if (square[0][0] + square[1][1] + square[2][2] !=15)
			{
				checkMagic = 0;
			}

		//For the diagonal 2:
			else if (square[0][2] + square[1][1] + square[2][0] !=15)
			{
				checkMagic = 0;
			}
			else
			{
				cout <<"This is a magic square"<<endl;
				checkMagic = 1;
			}
		return checkMagic;
	}

///////SHOWBOARD FUNCTION
int showBoard(array< array<int, 3>, 3> square)
	{
		for(int j = 0; j<3; j++)
		{
			for(int k =0; k<3; k++ )
			{
				cout << square[j][k];
			}
		cout<<endl;
		}
	return 0;
	}
